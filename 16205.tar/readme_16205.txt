Hello sir,
         Dictionary Structure Program,
File dict.h contains functions required to insert words into dictionary and search word from dictionary,

[1] -> To compile: make dict
[2] -> To run: make run

Thanks n Regards
Suraj Rajendra Bhosale.
