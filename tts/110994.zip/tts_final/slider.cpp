// slider.cpp : implementation file
//

#include "stdafx.h"
#include "tts_final.h"
#include "slider.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// slider

slider::slider()
{
		
}


slider::~slider()
{
}


BEGIN_MESSAGE_MAP(slider, CSliderCtrl)
	//{{AFX_MSG_MAP(slider)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// slider message handlers




