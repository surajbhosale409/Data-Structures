#if !defined(AFX_SLIDER_H__EFC00DBB_DE88_4F77_901E_1C4D191D4658__INCLUDED_)
#define AFX_SLIDER_H__EFC00DBB_DE88_4F77_901E_1C4D191D4658__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// slider.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// slider window

class slider : public CSliderCtrl
{
// Construction
public:
	slider();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(slider)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~slider();

	// Generated message map functions
protected:
	//{{AFX_MSG(slider)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SLIDER_H__EFC00DBB_DE88_4F77_901E_1C4D191D4658__INCLUDED_)
